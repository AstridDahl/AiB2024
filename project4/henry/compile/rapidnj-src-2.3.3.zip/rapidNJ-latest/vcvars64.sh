#!/bin/bash

export PATH="/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/Common7/IDE/":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/VC/bin/x86_amd64":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/Common7/Tools":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/VC/VCPackages":"/cygdrive/c/Program Files (x86)/Microsoft SDKs/Windows/v8.0A/bin/NETFX 4.0 Tools":"/cygdrive/c/Program Files (x86)/Microsoft SDKs/Windows/v8.0A/bin/x64":$PATH:

export INCLUDE="C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\INCLUDE;C:\Program Files (x86)\Microsoft SDKs\Windows\v8.0A\include;C:\projects\rapidNJ\trunk\lib\includes"

export LIB="C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\LIB\amd64;C:\Program Files (x86)\Windows Kits\8.0\Lib\win8\um\x64;C:\projects\rapidNJ\trunk\lib\x64;"