#!/bin/bash

export PATH=$PATH:"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/VSTSDB/Deploy":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/Common7/IDE/":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/VC/BIN":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/Common7/Tools":"/cygdrive/c/Windows/Microsoft.NET/Framework/v4.0.30319":"/cygdrive/c/Windows/Microsoft.NET/Framework/v3.5":"/cygdrive/c/Program Files (x86)/Microsoft Visual Studio 11.0/VC/VCPackages":"/cygdrive/c/Program Files (x86)/Microsoft SDKs/Windows/v8.0A/bin/NETFX 4.0 Tools":"/cygdrive/c/Program Files (x86)/Microsoft SDKs/Windows/v8.0A/bin":

export INCLUDE="C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\INCLUDE;C:\Program Files (x86)\Microsoft SDKs\Windows\v8.0A\include;C:\projects\rapidNJ\trunk\lib\includes;"

export LIB="C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\LIB;C:\pthreads-win32\Pre-built.2\lib;C:\Program Files (x86)\Windows Kits\8.0\Lib\win8\um\x86"