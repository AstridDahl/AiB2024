#ifndef CONSTANTS_HPP_
#define CONSTANTS_HPP_

#define threads_pr_block 128
#define gpuMemory 512

#endif
